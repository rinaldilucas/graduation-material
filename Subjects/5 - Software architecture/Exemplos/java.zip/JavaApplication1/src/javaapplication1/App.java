package javaapplication1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.List;

public class App {
    public static void main (String[] args) throws IOException {
        BufferedReader in = new BufferedReader (
            new FileReader("src/cidades.txt"));
            Scanner scan = new Scanner (System.in);
            String opcao = scan.nextLine();
            StrategyCidade strategy = null;
        
        switch (opcao) {
            case "txt":
                strategy = new StrategyTXT();
                break;
            case "csv":
                strategy = new StrategyCSV();
                break;
        }
        List <String> lista = strategy.ler();
        for (String cidade : lista) {
            System.out.println (cidade);
        }
        scan.close();
    }
}

/*case "csv":
                BufferedReader in_csv = new BufferedReader (
                    new FileReader("src/cidades.csv"));              
                String linha2 = in_csv.readLine();
                while (linha2 != null) {
                    System.out.println (linha2.substring(0, linha2.indexOf(",")));
                    if (!linha2.equals ("")) {
                        System.out.println(linha2);
                    }
                    linha2 = in_csv.readLine();
                }
                in_csv.close();
*/