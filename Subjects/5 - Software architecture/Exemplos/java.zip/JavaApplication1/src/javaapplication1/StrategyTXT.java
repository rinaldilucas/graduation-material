package javaapplication1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StrategyTXT extends StrategyCidade {
    BufferedReader in;
    public List<String> ler() {
        try {
            in = new BufferedReader(
                    new FileReader("src/cidades.txt"));
            String linha = in.readLine();
        List<String> lista = new ArrayList<String>();
        while (linha != null) {
            if (!linha.equals("")) {
                System.out.println(linha);
            }
            linha = in.readLine();
        }
        in.close();
        return lista;
        } catch (FileNotFoundException ex) {
            Logger.getLogger(StrategyTXT.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }
}
