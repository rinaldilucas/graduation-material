package javaapplication1;

import java.util.List;

public abstract class StrategyCidade {
    public abstract List <String> ler ();
}
