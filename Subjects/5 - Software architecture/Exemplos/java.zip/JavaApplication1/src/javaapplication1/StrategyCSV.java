package javaapplication1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.List;
import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class StrategyCSV extends StrategyCidade {
     BufferedReader in_csv;
    public List<String> ler() {
         try {
             in_csv = new BufferedReader(
                     new FileReader("src/cidades.csv"));
             String linha2 = in_csv.readLine();
        List<String> lista = new ArrayList<String>();
        while (linha2 != null) {
            lista.add (linha2.substring(0, linha2.indexOf(",")));
            linha2 = in_csv.readLine();
        }
        in_csv.close();
        return lista;
         } catch (FileNotFoundException ex) {
             Logger.getLogger(StrategyCSV.class.getName()).log(Level.SEVERE, null, ex);
         }        
    }
}
