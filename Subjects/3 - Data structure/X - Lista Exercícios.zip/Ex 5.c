//Aluno: Lucas Fredegoto Reinaldi, RA: 1478133
/*
Fa�a uma fila est�tica circular (representada por um vetor) e implemente as seguintes fun��es
para ela: a-)Insere
b-)Remove
c-)Imprime
*/

#define TAMANHO 20
#include <stdio.h>
#include <stdlib.h>

typedef struct fila {
    int inicio, fim;
    int total;
    int vetor[TAMANHO];
} Fila;

void inserir (Fila f, int valor) {
    f.fim = f.fim+1;
    f.vetor[f.fim] = valor;
}

void iniciaFila (Fila f) {
    f.inicio = 1;
    f.fim = f.inicio;
    f.total = 0;
}

void insere (Fila f, int valor) {
    if (f.total == 0) {
        printf ("Fila vazia.");
    } else if (f.total == TAMANHO) {
        printf ("Fila cheia.");
    }else {
        f.vetor[f.fim] = valor;
        f.fim = f.fim % TAMANHO;
        f.total++;
    }
}

void Desenfileira (Fila f, int valor) {
    if (f.fim % TAMANHO+1 == f.inicio) {
        printf ("Fila cheia.");
    } else {
        valor = f.vetor[f.inicio];
        f.inicio = f.inicio % TAMANHO+1;
    }
}

void imprime (Fila f) {
    int i;
    for (i = f.ini; i <= f.fim; i++) {
        printf ("%d\n", f.vetor[i]);
    }
}

main () {
    Fila f;
    f.inicio = 0;
    f.fim = 1;
    f.vetor[0] = 1;
    f.vetor[1] = 2;

    insere (f, 10);
    insere (f, 10);

    imprime (f);
}
