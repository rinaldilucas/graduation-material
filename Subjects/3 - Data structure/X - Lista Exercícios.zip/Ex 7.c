//Aluno: Lucas Fredegoto Reinaldi, RA: 1478133
/*
Fa�a uma fun��o que receba uma lista encadeada L1 e retorne a lista L1 com os elementos
invertidos. Para isso, dever� ser utilizada uma pilha. Exemplo: Lista1 = {1,2,3}, ap�s passar
pela fun��o a Lista1 ficar�: Lista1 = {3,2,1}.
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct lista {
    int info;
    struct lista *prox;
} Lista;

typedef struct pilha {
    Lista *topo;
} Pilha;

Lista *inserirFim (Lista *l, int valor) {
    Lista *aux = l;
    Lista *novo = (Lista *) malloc(sizeof(Lista));
    if (aux == NULL) {
        novo->info = valor;
        novo->prox = NULL;
        return novo;
    }
    while (aux->prox != NULL) {
        aux = aux->prox;
    }
    novo->info = valor;
    novo->prox = NULL;
    aux->prox = novo;
    return l;
}

void imprimeLista (Lista *l) {
    Lista *aux = l;
    if (aux == NULL)
        printf ("Vazio");
    while (aux != NULL) {
        printf ("%d ", aux->info);
        aux = aux->prox;
    }
}

Pilha* pilha_cria (void) {
    Pilha* p = (Pilha*) malloc(sizeof(Pilha));
    p->topo = NULL;
    return p;
}

int pilha_vazia (Pilha *p) {
    return (p->topo == NULL);
}

int pilha_pop(Pilha *p) {
    Lista *aux;
    int valor;
    if (pilha_vazia(p)) {
        printf ("Pilha vazia. \n");
        exit(1);
    }
    aux = p->topo;
    valor = aux->info;
    p->topo = aux->prox;
    free(aux);
    return valor;
}

void pilha_push (Pilha* p, int v) {
    Lista* n = (Lista*) malloc(sizeof(Lista));
    n->info = v;
    n->prox = p->topo;
    p->topo = n;
}

Lista *limpaLista (Lista *l) {
    Lista *aux = l;
    Lista *ant;
    if (l->prox == NULL) {
        free (l);
        l = NULL;
        return l;
    }
    while (aux != NULL) {
        ant = aux;
        aux = aux->prox;
        free (ant);
    }
    free (aux);
    l = NULL;
    return l;
}

Lista* inverte (Lista *l) {
    Lista *aux = l, *ant;
    Pilha *p;
    p = pilha_cria();

    while(aux != NULL) {
        pilha_push(p, aux->info);
        aux = aux->prox;
    }
    l = limpaLista(l);

     while(!pilha_vazia(p)){
        l = inserirFim(l, pilha_pop(p));
    }
    return l;
}

main () {
    Lista *l, *no1, *no2, *no3;
    l = NULL;
    no1 = (Lista *)malloc(sizeof(Lista));
    no2 = (Lista *)malloc(sizeof(Lista));
    no3 = (Lista *)malloc(sizeof(Lista));

    l = no1;
    no1->info = 10;
    no1->prox = no2;
    no2->info = 11;
    no2->prox = no3;
    no3->info = 12;
    no3->prox = NULL;

    printf ("Lista normal: ");
    imprimeLista(l);

    l = inverte(l);

    printf ("\nLista invertida: ");
    imprimeLista(l);

}


