//Aluno: Lucas Fredegoto Reinaldi, RA: 1478133
/*
Fa�a uma rotina para verificar se os elementos de uma fila (representada por listas
encadeadas) est�o ordenados de forma crescente.
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct lista {
    int info;
    struct lista *prox;
} lista;

typedef struct fila {
    lista *ini;
    lista *fim;
} fila;

void insereFilaFim (fila *f2, int valor) {
    lista *novo;
    novo = (lista *) malloc(sizeof(lista));
    novo->info = valor;
    novo->prox = NULL;
    if (f2->ini == NULL) {
        f2->ini = novo;
    } else {
        f2->fim->prox = novo;
    }
    f2->fim = novo;
}

void insereFilaIni (fila *f2, int valor) {
    lista *novo;
    novo = (lista *) malloc(sizeof(lista));
    novo->info = valor;
    novo->prox = NULL;
    if (f2->ini == NULL) {
        f2->ini = novo;
        f2->fim = novo;
    } else {
        novo->prox = f2->ini;
    }
    f2->ini = novo;
}

int filaVazia (fila *f){
    if (f->ini == NULL)
        return 1;
    else
        return 0;
}

int verificaCrescente (fila *f) {
    if (filaVazia(f) == 1) {
        printf ("Fila vazia. ");
        return 0;
    } else {
        lista *aux = f->ini;
        while (aux != NULL){
            if (aux->prox->prox == NULL) {
                if (aux->info >= aux->prox->info) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                if (aux->info >= aux->prox->info)
                    return 0;
                aux = aux->prox;
            }
        }
    }
}

main() {

    fila *f;
    lista *l1, *l2, *l3;
    f = (fila *) malloc(sizeof(fila));
    f->ini = f->fim = NULL;
    l1 = (lista *) malloc(sizeof(lista));
    l2 = (lista *) malloc(sizeof(lista));
    l3 = (lista *) malloc(sizeof(lista));
    l1->info = 10;
    l1->prox = l2;
    l2->info = 15;
    l2->prox = l3;
    l3->info = 20;
    l3->prox = NULL;

    f->ini = l1;
    f->fim = l3;


    if (verificaCrescente(f))
        printf ("A fila esta em ordem crescente.");
    else
        printf ("A fila nao esta em ordem crescente.")
}
