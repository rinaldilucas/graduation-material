//Aluno: Lucas Fredegoto Reinaldi, RA: 1478133
/*
Fa�a uma fun��o que receba uma pilha P1 e retorne essa mesma pilha com os elementos invertidos.
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct lista {
    int info;
    struct lista* prox;
} Lista;

typedef struct pilha {
    Lista* topo;
} Pilha;

Pilha* pilha_cria (void) {
    Pilha* p = (Pilha*) malloc(sizeof(Pilha));
    p->topo = NULL;
    return p;
}

int pilha_vazia(Pilha* p) {
    return (p->topo==NULL);
}
void pilha_push (Pilha* p, int v) {
    Lista* n = (Lista*) malloc(sizeof(Lista));
    n->info = v;
    n->prox = p->topo;
    p->topo = n;
}

int pilha_pop (Pilha* p) {
    Lista* t;
    int v;
    if (pilha_vazia(p)) {
        printf("Pilha vazia.\n");
        exit(1);/* aborta programa */
    }

    t = p->topo;
    v = t->info;
    p->topo = t->prox;
    free (t);
    return v;
}

void pilha_imprime(Pilha *p) {
    Lista* q = p->topo;
    while (q!=NULL) {
        printf("%d\n",q->info);
        q = q->prox;
    }
}

Lista * insere (Lista *l, int valor) {
    Lista *aux = l;
    Lista *novo = (Lista *)malloc(sizeof(Lista));
    novo->info = valor;
    if (l == NULL) {
        novo->prox = NULL;
        return novo;
    }
    while (aux->prox != NULL)
        aux = aux->prox;
    novo->prox = NULL;
    aux->prox = novo;
    return l;
}

void inverte (Pilha *p) {
    Pilha *aux = p;
    Lista *l = NULL;
    Lista *aux2;
    while(!pilha_vazia(p)) {
        l = insere(l, pilha_pop(p));
    }
    aux2 = l;
    while (aux2 != NULL) {
        pilha_push(p, aux2->info);;
        aux2 = aux2->prox;
    }
}

main() {
    Pilha* p1;
    p1 = pilha_cria();
    Lista* l= (Lista*) malloc (sizeof(Lista));
    l->info=1;
    l->prox = p1->topo;
    p1->topo = l;
    pilha_push(p1, 2);
    pilha_push(p1, 3);
    pilha_push(p1, 4);
    printf("Pilha:\n");
    pilha_imprime(p1);
    printf ("\nPilha invertida:\n");
    inverte(p1);
    pilha_imprime(p1);

}
