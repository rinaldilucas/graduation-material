//Aluno: Lucas Fredegoto Reinaldi, RA: 1478133
/*
Considere uma lista duplamente encadeada para armazenar n�meros inteiros. Implemente uma
fun��o que receba como par�metros uma lista com seus elementos ordenados em ordem
crescente e um n�mero inteiro x, e insira um novo n� na lista com o valor x, preservando a
ordena��o da lista.
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct lista {
    struct lista *prox;
    struct lista *ant;
    int valor;
} Lista;

void imprime (Lista *l) {
    Lista *aux = l;
    while (aux != NULL) {
        printf ("%d ", aux->valor);
        aux = aux->prox;
    }
}

Lista *insereOrdem (Lista *l, int valor) {
    Lista *novo = (Lista *)malloc(sizeof(Lista));
    novo->valor = valor;
    Lista *aux = l;
    Lista *ant = NULL;
    while (aux != NULL && valor > aux->valor) {
        ant = aux;
        aux = aux->prox;
    }
    if (ant == NULL) {
        novo->prox = l;
        novo->ant = NULL;
        return novo;
    }
    ant->prox = novo;
    novo->prox = aux;
    novo->ant = ant;
    return l;
}

main () {
    Lista *l = NULL;
    Lista *no1, *no2, *no3, *no4;
    no1 = (Lista *)malloc(sizeof(Lista));
    no2 = (Lista *)malloc(sizeof(Lista));
    no3 = (Lista *)malloc(sizeof(Lista));
    no4 = (Lista *)malloc(sizeof(Lista));

    l = no1;
    no1->valor = 10;
    no2->valor = 20;
    no3->valor = 30;
    no4->valor = 40;

    no1->prox = no2;
    no2->prox = no3;
    no3->prox = no4;
    no4->prox = NULL;

    l = insereOrdem(l, 45);
    imprime (l);
}
