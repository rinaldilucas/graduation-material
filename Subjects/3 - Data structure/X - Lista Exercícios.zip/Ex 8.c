//Aluno: Lucas Fredegoto Reinaldi, RA: 1478133
/*
Fa�a um programa que verifique se duas filas din�micas s�o iguais. Obs:implementar as
fun��es necess�rias para inser��o, remo��o e impress�o da fila din�mica
*/
#include <stdio.h>
#include <stdlib.h>

struct lista {
    float info;
    struct lista* prox;
};
typedef struct lista Lista;

struct fila {
    Lista* ini;
    Lista* fim;
};
typedef struct fila Fila;

Fila* fila_cria(void) {
    Fila* f = (Fila*) malloc(sizeof(Fila));
    f->ini = f->fim = NULL;
    return f;
}

int fila_vazia(Fila* f) {
    return(f->ini==NULL);
}

void fila_insere (Fila* f, float v) {
    Lista* n = (Lista*) malloc(sizeof(Lista));
    n->info = v;
    n->prox = NULL;
    if (f->fim != NULL)
        f->fim->prox = n;
    else
        f->ini = n;

    f->fim = n;
}

float fila_retira (Fila* f) {
    Lista* t;
    float v;
    if (fila_vazia(f)) {
        printf("Fila vazia.\n");
        exit(1);
    }

    t = f->ini;
    v = t->info;
    f->ini = t->prox;
    if (f->ini ==  NULL)
        f->fim = NULL;

    free(t);
    return v;
}

void fila_imprime (Fila* f) {
    Lista* q = f->ini;
    printf("FILA: ");
    if(q==NULL)
        printf("NULL");
    while (q!=NULL) {
        printf("%.2f ",q->info);
        q = q->prox;
    }
}

int iguais (Fila *f1, Fila *f2) {
    Lista *aux1, *aux2;
    int a = 0, b = 0;
    aux1 = f1->ini;
    aux2 = f2->ini;

    while (aux1 != NULL) {
        if (aux1->info != aux2->info)
            return 0;
        aux1 = aux1->prox;
        aux2 = aux2->prox;
        a++;
    }
    aux2 = f2->ini;
    while (aux2 != NULL) {
        aux2 = aux2->prox;
        b++;
    }
    if (a != b)
        return 0;
    return 1;
}

main() {
    Fila *f1, *f2;
    f1 = fila_cria();
    fila_insere(f1,5.5);
    fila_insere(f1,6.5);
    fila_insere(f1,5.0);
    fila_imprime(f1);

    printf ("\n");

    f2 = fila_cria();
    fila_insere(f2,5.5);
    fila_insere(f2,6.5);
    fila_insere(f2,5.0);
    fila_imprime(f2);

    printf ("\n");
    if (iguais(f1,f2))
        printf ("As filas sao iguais.");
    else
        printf ("As filas sao diferentes.");
}
