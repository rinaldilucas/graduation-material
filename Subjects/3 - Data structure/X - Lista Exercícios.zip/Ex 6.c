//Aluno: Lucas Fredegoto Reinaldi, RA: 1478133
/*
Construa uma fun��o que retorne a quantidade de n�meros primos em uma lista duplamente
encadeada. Obs: implementar as fun��es necess�rias para inser��o, remo��o e impress�o da
lista duplamente encadeada.
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct lista {
    int info;
    struct lista *prox;
    struct lista *ant;
} Lista;

Lista* inserirLista(Lista* l, int valor) {
    Lista* novo = (Lista *) malloc(sizeof(Lista));
    novo->info = valor;
    novo->prox = l;
    novo->ant = NULL;
    return novo;
}

void insereFim (Lista* l, int valor) {
    Lista *aux;
    aux = l;
    while (aux->prox != NULL)
        aux = aux->prox;

    Lista* novo = (Lista *) malloc(sizeof(Lista));
    aux->prox = novo;
    novo->info = valor;
    novo->prox = NULL;
    novo->ant = aux;
}

void imprime (Lista *l) {
    Lista *aux;
    aux = l;
    while (aux != NULL) {
        printf ("%d\n", aux->info);
        aux = aux->prox;
    }
}

Lista* apagar(Lista *l, int info) {
    Lista *aux = l, *ant = NULL;
    while((aux != NULL) && (aux->info != info)) {
        ant = aux;
        aux = aux->prox;
    }
    if(ant == NULL) {
        l = aux->prox;
        l->ant = NULL;
        free(aux);
    } else if(aux->prox==NULL) {
        ant->prox=NULL;
        free(aux);
    } else {
        ant->prox = aux->prox;
        aux->prox->ant = ant;
        free(aux);
    }
    return l;
}

int primos (Lista *l) {
    Lista *aux = l;
    int qde = 0, resto, i;
    while (aux != NULL) {
        if (aux->info == 1 || aux->info == 2)
            qde++;
        for (i = 2; i < aux->info; i++) {
            resto = aux->info%i;
            if (resto == 0)
                break;
        }
        if (resto != 0)
            qde++;
        aux = aux->prox;
    }
    return qde;
}

main () {
    Lista *l;
    l = NULL;

    l = inserirLista (l, 40);
    insereFim(l, 10);
    insereFim(l, 12);
    insereFim(l, 1);
    imprime (l);

    printf ("\n");

    printf ("Quantidade de numeros primos: %d\n", primos(l));
}

