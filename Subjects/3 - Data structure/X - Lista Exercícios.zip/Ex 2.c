//Aluno: Lucas Fredegoto Reinaldi, RA: 1478133
/*
Criar um TAD para lista simplesmente encadeada com todas as opera��es do exerc�cio 1.

a) Uma estrutura DEQUE � um TAD Fila em que elementos podem ser inseridos e retirados
de ambas as extremidades da estrutura (est�tica ou din�mica) APENAS. Outros tipos de
inser��o e remo��o (em outras posi��es) n�o s�o v�lidos. Escreva um programa com as
fun��es necess�rias para implementar um DEQUE representado por uma lista encadeada.
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct lista {
    int valor;
    struct lista *prox;
} Lista;

void imprime (Lista *l) {
    Lista *aux = l;
    while (aux != NULL) {
        printf ("%d ", aux->valor);
        aux = aux->prox;
    }
}

Lista *inserirComeco (Lista *l, int valor) {
    Lista *aux = l;
    Lista *novo = (Lista *) malloc(sizeof(Lista));
    novo->prox = aux;
    novo->valor = valor;
    l = novo;
    return l;
}

Lista *inserirFim (Lista *l, int valor) {
    Lista *aux = l;
    Lista *novo = (Lista *) malloc(sizeof(Lista));
    if (aux == NULL) {
        novo->valor = valor;
        novo->prox = NULL;
        return novo;
    }
    while (aux->prox != NULL) {
        aux = aux->prox;
    }
    novo->valor = valor;
    novo->prox = NULL;
    aux->prox = novo;
    return l;
}

Lista *deletarComeco (Lista *l) {
    Lista *aux = l;
    l = l->prox;
    free (aux);
    return l;
}

Lista *deletarFim (Lista *l) {
    Lista *aux = l;
    Lista *ant;
    if (l->prox == NULL) {
        free (aux);
        l = NULL;
        return l;
    }
    while (aux->prox != NULL) {
        ant = aux;
        aux = aux->prox;
    }
    ant->prox = NULL;
    free (aux);
    return l;
}

main () {
    Lista *l;
    l = NULL;
    l = inserirComeco (l, 10);
    l = inserirComeco (l, 20);
    imprime(l);
    printf ("\n-----------------------------\n");
    l = inserirFim (l, 30);
    l = inserirFim (l, 40);
    imprime(l);
    printf ("\n-----------------------------\n");
    l = deletarComeco(l);
    l = deletarComeco(l);
    imprime(l);
    printf ("\n-----------------------------\n");
    l = deletarFim (l);
    l = deletarFim (l);
    imprime(l);

}

