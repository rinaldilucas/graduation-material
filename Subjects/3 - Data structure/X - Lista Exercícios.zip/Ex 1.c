//Aluno: Lucas Fredegoto Reinaldi, RA: 1478133
/*
Criar um TAD para lista duplamente encadeada que contenha as seguintes opera��es:
a) void filaVazia(TipoLista *lista): faz lista vazia;
b) void Insere(TipoItem x, TipoLista *lista): insere elemento x na �ltima posi��o da lista;
c) void InsereAposElemento(TipoItem x, TipoLista *Elem): insere elemento x ap�s o n�
Elem;
d) TipoLista *RemoveElemento(TipoItem E): remove da lista o n� com o elemento E. Retorna
a lista modificada;
e) void ImprimeLista(TipoLista *lista): imprime os elementos da lista;
f) int ContaElementos(TipoLista *lista): conta o n�mero de elementos na lista;
*/
#include <stdio.h>
#include <stdlib.h>

typedef struct item {
    int info;
} TipoItem;

typedef struct lista {
    struct lista *prox;
    struct lista *ant;
    TipoItem valor;
} TipoLista;

void imprime (TipoLista *l) {
    if (l->prox == NULL) {
        printf ("%d ", l->valor.info);
    } else {
        printf ("%d ", l->valor.info);
        imprime(l->prox);
    }
}

TipoLista *listaVazia (TipoLista *lista) {
    return NULL;
}

int testaLista(TipoLista * L) {
    return (L == NULL);
}

TipoLista *inserirFim (TipoItem x, TipoLista *l) {
    TipoLista *aux = l;
    TipoLista *novo = (TipoLista *)malloc(sizeof(TipoLista));
    novo->valor = x;
    novo->prox = NULL;
    novo->ant = NULL;

    if (testaLista(l)) {
        return novo;
    } else {
        while (aux->prox != NULL) {
            aux = aux->prox;
        }
        novo->ant = aux;
        aux->prox = novo;
    }
    return l;
}

TipoLista *inserirPosicao (TipoItem x, TipoLista *v, TipoLista *l) {
    TipoLista *aux = l;
    TipoLista *novo = (TipoLista *)malloc(sizeof(TipoLista));
    novo->valor = x;
    novo->prox = NULL;
    novo->ant = NULL;

    while (aux != NULL && aux->valor.info != v->valor.info) {
        aux = aux->prox;
    }
    if (testaLista(l)) {
        return novo;
    } else {
        if (aux->prox == NULL) {
            aux->prox = novo;
            novo->ant = aux;
        } else {
            novo->ant = aux;
            novo->prox = aux->prox;
            aux->ant->prox = novo;
            aux->prox->ant = novo;
        }
    }
    return l;
}

TipoLista *removeElemento (TipoItem x, TipoLista *l) {
    TipoLista *aux = l;
    TipoLista *ant = NULL;
    while (aux != NULL && aux->valor.info != x.info) {
        ant = aux;
        aux = aux->prox;
    }
    if (ant == NULL) {
        l = aux->prox;
        l->ant = NULL;
        free(aux);
    } else if (aux->prox == NULL) {
        ant->prox = NULL;
        free(aux);
    } else {
        ant->prox = aux->prox;
        aux->prox->ant = ant;
        free(aux);
    }
    return l;
}

int contaElementos (TipoLista *l) {
    TipoLista *aux = l;
    int qde = 0;
    while (aux != NULL){
        qde++;
        aux = aux->prox;
    }
    return qde;
}

main () {
    TipoLista *l;
    TipoItem valor1, valor2, valor3;

    valor1.info = 10;
    valor2.info = 20;
    valor3.info = 30;

    l = listaVazia(l);
    l = inserirFim(valor1, l);
    l = inserirFim(valor3, l);;
    l = inserirPosicao(valor2, l->prox, l);
    l = removeElemento(valor2, l);

    imprime (l);

    printf ("A quantidade de elementos na lista e: %d.", contaElementos(l));
}
