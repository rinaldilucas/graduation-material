package utfpr.edu.pd;

import javax.swing.JTextArea;

public class Thread5 implements Runnable {

    JTextArea jArea;

    public Thread5(JTextArea jArea) {
        this.jArea = jArea;
    }

    @Override
    public void run() {
        for (int i = 0; i < 20; i++) {
            jArea.append(i+"\n");
        }
    }

}
