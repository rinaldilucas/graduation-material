package utfpr.edu.pd;

public class Thread3 implements Runnable {

    protected boolean parar=false;
    
    @Override
    public void run() {
        while (!parar) {
            for (int i = 0; i < 20; i++) {
                System.out.println(" i = " + i);
            }
        }
    }

}
