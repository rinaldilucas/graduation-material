package utfpr.edu.pd;

public class Thread2 implements Runnable{
    
    private String nome;
    
    public Thread2(){}
    
    public Thread2(String nome){
        this.nome=nome;
    }

    @Override
    public void run() {
        for(int i=0;i<10;i++)
            System.out.println(nome+" i = "+i);
    }
    
}
