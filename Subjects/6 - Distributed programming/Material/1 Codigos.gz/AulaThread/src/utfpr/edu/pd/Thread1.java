package utfpr.edu.pd;

public class Thread1 extends Thread{
    
    public void run(){
        for(int i=0;i<10;i++)
            System.out.println(" i = "+i);
    }

    public static void main(String[] args) {
        System.out.println("Ola thread");
         Thread1 t1=new Thread1();
        t1.setDaemon(false);
        t1.start();
        System.out.println("Fim do programa");
        Thread1 t2=new Thread1();
        t2.start();
        Thread1 t3=new Thread1();        
        t3.start();
        
        Thread t4=new Thread(new Thread2("Primeira"));
        t4.start();
        
        for(int i=0;i<5;i++)
            new Thread(new Thread2("Thread"+i)).start();
    }
    
}
