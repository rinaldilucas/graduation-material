package tcp;

import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Cliente {
    
    public static Socket conexao;
    public static DataInputStream entrada;
    public static DataOutputStream saida;
    
    public static void main(String[] args) {
        try {
            // estabelecer conexao servidor
            conexao=new Socket("localhost",4000);
            
            // coletar dados cliente e enviar p servidor
            String informacao=JOptionPane.showInputDialog("Digite uma mensagem");
            saida=new DataOutputStream(conexao.getOutputStream());
            saida.writeUTF(informacao);
            
            // receber dados do servidor
            entrada=new DataInputStream(conexao.getInputStream());
            informacao=entrada.readUTF();
            
            // exibir dados            
            System.out.println("Dados = "+informacao);
            
            // fechar conexao
            conexao.close();
            
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
