package tcp;



import java.util.logging.Level;
import java.util.logging.Logger;

public class Servidor {
    
    public static Socket conexao;
    public static ServerSocket servidor;
    
    public static DataInputStream entrada;
    public static DataOutputStream saida;
    
    public static void main(String[] args) {
        
        try {
            // Estabelecer porta
            servidor=new ServerSocket(4000);
            conexao=servidor.accept();
            
            // Ler dados que o cliente enviou
            entrada=new DataInputStream(conexao.getInputStream());
            String dados=entrada.readUTF();
            
            // processar
            dados=dados.toUpperCase();
            
            //Enviar dados ao cliente
            saida=new DataOutputStream(conexao.getOutputStream());
            saida.writeUTF(dados);
            
            // fechar conexao
            conexao.close();
        } catch (IOException ex) {
            Logger.getLogger(Servidor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
