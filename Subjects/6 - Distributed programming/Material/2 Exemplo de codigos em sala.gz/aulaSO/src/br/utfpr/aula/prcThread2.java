package br.utfpr.aula;

public class prcThread2 {
    
    public static void main(String[] args) {
        new Thread(new Thread2()).start();
        new Thread(new Thread2()).start();
        new Thread(new Thread2()).start();
        new Thread(new Thread2()).start();
        new Thread(new Thread2()).start();
        new Thread(new Thread2()).start();
    }
    
}
