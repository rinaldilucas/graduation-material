package br.utfpr.aula;

import javax.swing.JTextArea;

public class ThreadArea implements Runnable{

    JTextArea jTextThread;
    
    public ThreadArea(){
        
    }
    
    public ThreadArea(JTextArea jTextArea){
        this.jTextThread=jTextArea;        
    }
    
    @Override
    public void run() {
        
        for(int i=0;i<=5;i++)
            this.jTextThread.append(" i = "+i+"\n");
        
    }
    
}
