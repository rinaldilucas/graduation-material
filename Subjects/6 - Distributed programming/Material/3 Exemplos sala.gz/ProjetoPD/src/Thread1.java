
public class Thread1 implements Runnable{
    
    Variavel v;
    
    public Thread1(){}
    
    public Thread1(Variavel v){
        this.v=v;
    }

    @Override
    public void run() {
        for(int i=0;i<200;i++)
            this.v.setX(this.v.getX()+1);
        System.out.println(" Valor = "+this.v.getX());
    }
    
}
