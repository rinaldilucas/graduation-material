public class Variavel {
    
    private int x;
    
    public Variavel(){}
    
    public Variavel(int x){
        this.x=x;
    }

    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        this.x = x;
    }
    
    
    
}
