
public class Principal {
    
    public static void main(String[] args) {
        Variavel v=new Variavel(0);
        Thread t1=new Thread(new Thread1(v));
        Thread t2=new Thread(new Thread1(v));
        t1.start();
        t2.start();
    }
    
}
