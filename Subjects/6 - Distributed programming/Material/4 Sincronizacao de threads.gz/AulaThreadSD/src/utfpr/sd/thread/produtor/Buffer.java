package utfpr.sd.thread.produtor;

public interface Buffer {
    
    public void set(int valor);
    
    public int get();
    
}
