/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.jsf;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

/**
 *
 * @author utfpr
 */
@ManagedBean
@RequestScoped
public class JsfMeuBean {

    /**
     * Creates a new instance of JsfMeuBean
     */
    public JsfMeuBean() {
    }
    
    private String cor;
    private boolean full;
    private int x;
    
    public void dobrar(){
        x = x*2;
        cor = "" + x;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public String getCor() {
        System.out.println("################# Invoc. getCor()");
        return cor;
    }

    public void setCor(String cor) {
        System.out.println("#############  setCor ##########");
        this.cor = cor;
    }

    public boolean isFull() {
        return full;
    }

    public void setFull(boolean full) {
        this.full = full;
    }
    
    
}
