/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.jsf;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ApplicationScoped;

/**
 *
 * @author utfpr
 */
@ManagedBean
@ApplicationScoped
public class JsfApplication {

    /**
     * Creates a new instance of JsfRequest
     */
    public JsfApplication() {
    }
    
    private int valor1;
    private int valor2;

    public void dobrar(){
        valor2 = valor1*2;
    }
    
    public int getValor1() {
        return valor1;
    }

    public void setValor1(int valor1) {
        this.valor1 = valor1;
    }

    public int getValor2() {
        return valor2;
    }

    public void setValor2(int valor2) {
        this.valor2 = valor2;
    }
    
    
    
}
