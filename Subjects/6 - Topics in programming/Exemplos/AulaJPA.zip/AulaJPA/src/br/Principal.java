/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br;

/**
 *
 * @author utfpr
 */
public class Principal {
    public static void main(String[] args) {
        for(br.data.entity.Cidades cid: 
                new br.data.crud.CrudCidades().getAll()){
            System.out.println("========");
            System.out.println(cid.getCodigo());
            System.out.println(cid.getNome());
        }
        
        br.data.entity.Cidades cidade = new br.data.entity.Cidades();
        cidade.setCodigo(10);
        cidade.setNome("nova cidade");
        new br.data.crud.CrudCidades().persist(cidade);
    }
   
}
