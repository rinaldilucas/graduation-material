/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.validator;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.ValidatorException;

/**
 *
 * @author utfpr
 */
@FacesValidator("br.teste.primo")
public class ValidadorPrimo implements javax.faces.validator.Validator {
   
    @Override
    public void validate(FacesContext fc, UIComponent uic, Object o) throws ValidatorException {
        String svalor = o.toString();
        int valor = Integer.parseInt(svalor);
        if (!isPrimo(valor)) {  //verifica se o numero é primo
            javax.faces.application.FacesMessage msg
                    = new javax.faces.application.FacesMessage("Não eh um numero primo");
            msg.setSeverity(javax.faces.application.FacesMessage.SEVERITY_ERROR);
            throw new javax.faces.validator.ValidatorException(msg);
        }
    }

    private boolean isPrimo(int valor) {
        if(valor==5){
            return true;
        }else{
            return false;
        }
    }
}
