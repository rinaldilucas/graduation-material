/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.data.crud;

import br.data.entity.Cidades;
import java.util.ArrayList;

public class CrudCidades {
    
    public ArrayList<Cidades> getAll(){
        ArrayList<Cidades> lcid;
        lcid = new ArrayList<>();
        lcid.add(new Cidades(1, "Assis"));
        lcid.add(new Cidades(2, "Cornélio"));
        lcid.add(new Cidades(3, "Londrina"));
        lcid.add(new Cidades(4, "Marilia"));
        lcid.add(new Cidades(5, "Lins"));
        lcid.add(new Cidades(6, "Tupa"));
        lcid.add(new Cidades(7, "Garca"));
        lcid.add(new Cidades(8, "Floripa"));
        return lcid;
    }
}
