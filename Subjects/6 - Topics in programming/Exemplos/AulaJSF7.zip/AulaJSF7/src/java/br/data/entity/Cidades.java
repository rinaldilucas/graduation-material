/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.data.entity;

/**
 *
 * @author utfpr
 */
public class Cidades {
    private int Codigo;
    private String nome;

    public Cidades() {
    }

    public Cidades(int Codigo, String nome) {
        this.Codigo = Codigo;
        this.nome = nome;
    }

    
    
    public int getCodigo() {
        return Codigo;
    }

    public void setCodigo(int Codigo) {
        this.Codigo = Codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
