/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bdsample1;

/**
 *
 * @author utfpr
 */
public class BDSample1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        bdsample1.data.Crud cr = new bdsample1.data.Crud();
        System.out.println("Lista de cidades");
        for (bdsample1.data.Cidades cid : cr.getAll()) {
            System.out.println(cid.getNome());
        }
    }
    
}
