import { Component } from '@angular/core';
import { BatteryStatus } from 'ionic-native';

@Component({
	templateUrl: 'build/pages/home/home.html'
})
export class HomePage {

	public nivel_bar;
	public color;
	public bateria;

	constructor() {
		this.bateria = BatteryStatus.onChange().subscribe(
			status => {
				this.nivel_bar = (status.level / 100) * 235;
				this.color = (status.level > 50) ? 'happy' : 'sad';
			}
		);
	}

	ngOnDestroy() {
		this.bateria.unsubscribe();
	}
}
